"""Optional bounded local stdio adapter. No transport is loaded by the engine.

Callbacks are cooperative. Framing/storage bounds are not process memory bounds.
Unsupported host adapters are explicit; no dynamic model loading or code evaluation.
"""
from dataclasses import dataclass
from collections import OrderedDict
from itertools import count
import re

_U64 = (1 << 64) - 1
_epochs = count(1)
_SAFE = frozenset(b'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_.:')

class ProtocolError(ValueError):
    def __init__(self, code): self.code = code; super().__init__(code)

@dataclass(frozen=True)
class ProtocolLimits:
    max_frame_bytes: int = 65536
    max_fields: int = 64
    max_field_bytes: int = 8192
    max_input_bytes: int = 8192
    max_cache_entries: int = 64
    max_cache_bytes: int = 4 * 1024 * 1024
    max_handles: int = 64
    def __post_init__(self):
        for name in self.__dataclass_fields__:
            if type(getattr(self, name)) is not int or getattr(self, name) < 1: raise ValueError(name)
        if self.max_frame_bytes > (1 << 32) - 1: raise ValueError('frame limit')

@dataclass(frozen=True)
class ProtocolAuthority:
    deliver_inputs: bool = False
    configure_watches: bool = False
    configure_diagnostics: bool = False
    read_exact_values: bool = False
    export_exact_trace: bool = False
    def __post_init__(self):
        if any(type(getattr(self,n)) is not bool for n in self.__dataclass_fields__): raise ValueError('authority must be boolean')

def _u64(value):
    if type(value) is not int or not 0 <= value <= _U64: raise ProtocolError('malformed')
    return value

def _number(field):
    if not re.fullmatch(r'u64:[0-9]+', field): raise ProtocolError('malformed')
    return _u64(int(field[4:]))

def escape(value):
    return ''.join(chr(b) if b in _SAFE else '%%%02X' % b for b in value.encode('utf-8'))

def _unescape(value, maximum):
    output = bytearray(); index = 0
    while index < len(value):
        b = value[index]
        if b == 37:
            if index + 2 >= len(value): raise ProtocolError('malformed')
            pair = value[index+1:index+3]
            if not re.fullmatch(b'[0-9a-fA-F]{2}', pair): raise ProtocolError('malformed')
            output.append(int(pair,16)); index += 3
        else:
            if b not in _SAFE: raise ProtocolError('malformed')
            output.append(b); index += 1
        if len(output) > maximum: raise ProtocolError('limit')
    try: return output.decode('utf-8', errors='strict')
    except UnicodeError: raise ProtocolError('malformed') from None

def _encode(fields, limits):
    if any(len(f.encode('utf-8')) > limits.max_field_bytes for f in fields): raise ProtocolError('limit')
    result = '\t'.join(map(escape, fields)).encode('ascii')
    if not result or len(result) > limits.max_frame_bytes: raise ProtocolError('limit')
    return result

@dataclass(frozen=True)
class Request:
    session: str
    epoch: int
    request_id: int
    expected_revision: int
    expected_configuration: int
    command: str
    arguments: tuple[str, ...] = ()
    version: int = 1


def encode_request(request, limits=ProtocolLimits()):
    for n in (request.epoch,request.request_id,request.expected_revision,request.expected_configuration): _u64(n)
    fields = ('DDBG', 'u32:'+str(request.version), 'request', 'string:'+request.session,
        *(f'u64:{n}' for n in (request.epoch,request.request_id,request.expected_revision,request.expected_configuration)),request.command,*request.arguments)
    if len(fields) > limits.max_fields: raise ProtocolError('limit')
    return _encode(fields, limits)


def decode_request(payload, limits=ProtocolLimits()):
    if not payload or len(payload) > limits.max_frame_bytes: raise ProtocolError('limit')
    raw = payload.split(b'\t')
    if len(raw)>limits.max_fields: raise ProtocolError('limit')
    f = [_unescape(v,limits.max_field_bytes) for v in raw]
    if len(f)<9 or f[0]!='DDBG' or f[2]!='request' or not f[3].startswith('string:'): raise ProtocolError('malformed')
    if not re.fullmatch(r'u32:[0-9]+',f[1]) or int(f[1][4:]) > (1<<32)-1: raise ProtocolError('malformed')
    return Request(f[3][7:],*map(_number,f[4:8]),f[8],tuple(f[9:]),int(f[1][4:]))

@dataclass(frozen=True)
class Response:
    session: str
    epoch: int
    request_id: int
    revision: int
    configuration: int
    error: str | None
    fields: tuple[tuple[str,str], ...] = ()

def encode_response(response, limits=ProtocolLimits()):
    return _encode(('DDBG','u32:1','response','string:'+response.session,
        *(f'u64:{_u64(n)}' for n in (response.epoch,response.request_id,response.revision,response.configuration)),
        'error' if response.error else 'ok',response.error or 'none',f'u64:{len(response.fields)}',
        *(v for pair in response.fields for v in pair)), limits)

def decode_response(payload, limits=ProtocolLimits()):
    if not payload or len(payload)>limits.max_frame_bytes: raise ProtocolError('limit')
    f=[_unescape(v,limits.max_field_bytes) for v in payload.split(b'\t')]
    if len(f)<11 or f[:3]!=['DDBG','u32:1','response'] or not f[3].startswith('string:') or f[8] not in ('ok','error'): raise ProtocolError('malformed')
    n=_number(f[10])
    if len(f)!=11+2*n or (f[8]=='ok') != (f[9]=='none'): raise ProtocolError('malformed')
    return Response(f[3][7:],*map(_number,f[4:8]),None if f[9]=='none' else f[9],tuple(zip(f[11::2],f[12::2])))

def _read_exact(reader, size):
    parts = bytearray()
    while len(parts)<size:
        chunk=reader.read(size-len(parts))
        if not chunk: raise EOFError('partial protocol frame')
        parts.extend(chunk)
    return bytes(parts)

def read_frame(reader, maximum=65536):
    first=reader.read(1)
    if not first: return None
    size=int.from_bytes(first+_read_exact(reader,3),'big')
    if not 0<size<=maximum: raise ProtocolError('limit')
    return _read_exact(reader,size)

def write_frame(writer,payload,maximum=65536):
    if not 0<len(payload)<=min(maximum,(1<<32)-1): raise ProtocolError('limit')
    data=len(payload).to_bytes(4,'big')+payload
    view=memoryview(data)
    while view:
        n=writer.write(view)
        if n is None or n<=0: raise OSError('partial protocol write')
        view=view[n:]
    writer.flush()

class ProtocolSession:
    def __init__(self, session, *, decode_input=None, authority=ProtocolAuthority(), limits=ProtocolLimits()):
        self.session,self.decode_input,self.authority,self.limits=session,decode_input,authority,limits
        self.configuration=0; self._busy=False; self.reconnect()
    def reconnect(self):
        if getattr(self,'_busy',False): raise ProtocolError('busy')
        self.epoch=_u64(next(_epochs)); self.connected=True; self._cache=OrderedDict(); self._cache_bytes=0; self._high=0; self._handles={}; self._next_handle=1
        return self.epoch
    def disconnect(self): self.connected=False
    def _response(self,id,error=None,fields=()):
        return Response(self.session.id,self.epoch,id,self.session.revision,self.configuration,error,tuple(fields))
    def handle(self,request):
        if self._busy: return self._response(request.request_id,'busy')
        if request.version!=1: return self._response(request.request_id,'unsupported_version')
        if request.session!=self.session.id: return self._response(request.request_id,'wrong_session')
        if request.epoch==0 and request.command=='status':
            from dataclasses import replace
            request=replace(request,epoch=self.epoch)
        if request.epoch!=self.epoch: return self._response(request.request_id,'wrong_epoch')
        if not self.connected: return self._response(request.request_id,'disconnected')
        try:
            if request.request_id==0: raise ProtocolError('malformed')
            encoded=encode_request(request,self.limits)
        except ProtocolError as e: return self._response(request.request_id,e.code)
        cached=self._cache.get(request.request_id)
        if cached: return cached[1] if cached[0]==encoded else self._response(request.request_id,'duplicate_conflict')
        if request.request_id<=self._high: return self._response(request.request_id,'retired_request')
        self._high=request.request_id; self._busy=True
        try:
            try: response=self._response(request.request_id,fields=self._execute(request))
            except ProtocolError as e: response=self._response(request.request_id,e.code)
            except Exception: response=self._response(request.request_id,'callback')
            try: wire=encode_response(response,self.limits)
            except ProtocolError: response=self._response(request.request_id,'limit'); wire=encode_response(response,self.limits)
            size=len(encoded)+len(wire)+128
            if size<=self.limits.max_cache_bytes:
                while self._cache and (len(self._cache)>=self.limits.max_cache_entries or self._cache_bytes+size>self.limits.max_cache_bytes):
                    _,old=self._cache.popitem(last=False); self._cache_bytes-=old[2]
                self._cache[request.request_id]=(encoded,response,size); self._cache_bytes+=size
            return response
        finally: self._busy=False
    def _execute(self,r):
        c,a=r.command,r.arguments
        if c in ('status','snapshot','cancel') and a: raise ProtocolError('malformed')
        if r.expected_revision!=self.session.revision: raise ProtocolError('stale_revision')
        if r.expected_configuration!=self.configuration: raise ProtocolError('stale_configuration')
        if c=='status': return (('mode','enum:simulation'),('phase','enum:'+self.session.phase),('sequence',f'u64:{self.session.sequence}'),('capabilities.effects','bool:false'))
        if c=='snapshot':
            if len(self._handles)>=self.limits.max_handles: self._handles.pop(next(iter(self._handles)))
            h=_u64(self._next_handle); self._next_handle+=1; self._handles[h]=self.session.revision
            return (('snapshot.handle',f'u64:{h}'),)
        if c in ('checks','outputs','inspect','export_trace'):
            if not a: raise ProtocolError('malformed')
            handle=_number(a[0])
            if self._handles.get(handle)!=self.session.revision: raise ProtocolError('stale_handle')
            raise ProtocolError('unsupported')
        if c in ('step','cancel'):
            if not self.authority.deliver_inputs: raise ProtocolError('unauthorized')
            if self.session.phase in ('ended','disconnected'): raise ProtocolError('ended')
            if c=='cancel': self.session.cancel(r.expected_revision); return ()
            if len(a)!=1 or not re.fullmatch(r'bytes:(?:[0-9a-fA-F]{2})*',a[0]): raise ProtocolError('malformed')
            if len(a[0][6:])//2>self.limits.max_input_bytes: raise ProtocolError('limit')
            if self.decode_input is None: raise ProtocolError('unsupported')
            try: value=self.decode_input(bytes.fromhex(a[0][6:]))
            except Exception: raise ProtocolError('invalid_input') from None
            try: result=self.session.step(r.expected_revision,value)
            except Exception as e:
                if 'not permitted' in str(e): raise ProtocolError('invalid_input') from None
                raise
            return (('step.delivered','bool:'+str(result.delivered).lower()),('sequence',f'u64:{result.sequence}'))
        raise ProtocolError('unsupported')

def serve(session,reader,writer):
    try:
        while True:
            payload=read_frame(reader,session.limits.max_frame_bytes)
            if payload is None: return
            try: response=session.handle(decode_request(payload,session.limits))
            except ProtocolError as e: response=session._response(0,e.code)
            write_frame(writer,encode_response(response,session.limits),session.limits.max_frame_bytes)
    finally: session.disconnect()
