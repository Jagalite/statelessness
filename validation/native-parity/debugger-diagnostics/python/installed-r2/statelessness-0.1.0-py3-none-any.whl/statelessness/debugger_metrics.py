"""Optional bounded typed cumulative diagnostics, with explicit clock ownership.

Duration quantities are integer nanoseconds. Histogram quantiles are upper-bound
estimates. Imported/replay observations do not become live accounting authority.
"""
from dataclasses import dataclass, replace
from .core import U64_MAX, ModelError, _natural


@dataclass(frozen=True)
class LocalInstant:
    domain: int
    nanos: int
    def __post_init__(self):
        _natural(self.domain, 'clock domain'); _natural(self.nanos, 'nanoseconds')
    def elapsed_since(self, start):
        if type(start) is not LocalInstant: raise ValueError('expected LocalInstant')
        if self.domain != start.domain: raise ModelError('different clock domain')
        if self.nanos < start.nanos: raise ModelError('reversed clock')
        return self.nanos - start.nanos


class MonotonicClock:
    def __init__(self, domain):
        _natural(domain, 'clock domain')
        import time
        self._now, self._start, self._domain = time.monotonic_ns, time.monotonic_ns(), domain
    def now(self): return LocalInstant(self._domain, self._now() - self._start)


@dataclass(frozen=True)
class HistogramSchema:
    id: int
    finite_bounds_ns: tuple[int, ...]
    def __post_init__(self):
        _natural(self.id, 'histogram schema')
        bounds = tuple(self.finite_bounds_ns)
        if not bounds or len(bounds) > 64: raise ValueError('histogram requires 1..64 finite bounds')
        for index, value in enumerate(bounds):
            _natural(value, 'histogram bound')
            if index and value <= bounds[index-1]: raise ValueError('histogram bounds must increase')
        object.__setattr__(self, 'finite_bounds_ns', bounds)


@dataclass(frozen=True)
class Quantile:
    upper_bound_ns: int | None
    observations: int
    low_sample_warning: bool


@dataclass(frozen=True)
class Histogram:
    buckets: tuple[int, ...]
    count: int = 0
    sum_ns: int = 0
    def __post_init__(self):
        buckets = tuple(self.buckets)
        if not 2 <= len(buckets) <= 65: raise ValueError('invalid bucket count')
        for value in buckets: _natural(value, 'bucket observations')
        _natural(self.count, 'histogram observations')
        _natural(self.sum_ns, 'histogram sum', maximum=(1 << 128)-1)
        if sum(buckets) != self.count: raise ValueError('bucket counts disagree with observations')
        object.__setattr__(self, 'buckets', buckets)
    @classmethod
    def empty(cls, schema): return cls((0,) * (len(schema.finite_bounds_ns) + 1))
    def observe(self, schema, nanos):
        _natural(nanos, 'duration')
        if len(self.buckets) != len(schema.finite_bounds_ns)+1: raise ModelError('incompatible histogram schema')
        index = next((i for i, bound in enumerate(schema.finite_bounds_ns) if nanos <= bound), len(schema.finite_bounds_ns))
        if self.count == U64_MAX or self.buckets[index] == U64_MAX or self.sum_ns > (1 << 128)-1-nanos:
            raise ModelError('histogram arithmetic overflow')
        buckets = list(self.buckets); buckets[index] += 1
        return Histogram(tuple(buckets), self.count + 1, self.sum_ns + nanos)
    def quantile(self, schema, numerator, denominator):
        _natural(numerator, 'quantile numerator'); _natural(denominator, 'quantile denominator')
        if self.count == 0 or denominator == 0 or numerator > denominator: return None
        if len(self.buckets) != len(schema.finite_bounds_ns)+1: raise ModelError('incompatible histogram schema')
        rank = max(1, (self.count * numerator + denominator-1) // denominator)
        total = 0
        for index, count in enumerate(self.buckets):
            total += count
            if total >= rank:
                bound = schema.finite_bounds_ns[index] if index < len(schema.finite_bounds_ns) else None
                return Quantile(bound, self.count, self.count < 100)
        return None


@dataclass(frozen=True)
class LabelCatalog:
    operations: tuple[str, ...] = ('unknown',)
    components: tuple[str, ...] = ('unknown',)
    worker_pools: tuple[str, ...] = ('unknown',)
    def __post_init__(self):
        for name in ('operations', 'components', 'worker_pools'):
            labels = tuple(getattr(self, name))
            if not 1 <= len(labels) <= 256 or len(set(labels)) != len(labels): raise ValueError('invalid label catalog')
            if any(type(v) is not str or not v or len(v.encode('utf8')) > 64 for v in labels): raise ValueError('invalid label catalog entry')
            object.__setattr__(self, name, labels)


@dataclass(frozen=True)
class Labels:
    operation: int = 0
    component: int = 0
    worker_pool: int = 0
    outcome: str = 'none'
    origin: str = 'live'
    debugger_affected: bool = False
    def __post_init__(self):
        for field in ('operation', 'component', 'worker_pool'): _natural(getattr(self, field), field, maximum=65535)
        if self.outcome not in ('none','accepted','rejected','success','failure','cancelled','abandoned','ignored'): raise ValueError('invalid outcome')
        if self.origin not in ('live','debug-controlled-live','test-clock','replay-harness','imported-live'): raise ValueError('invalid origin')
        if type(self.debugger_affected) is not bool: raise ValueError('invalid debugger label')
    @property
    def ingests_live(self): return self.origin not in ('replay-harness', 'imported-live')


@dataclass(frozen=True)
class MetricValue:
    kind: str
    value: int | Histogram
    def __post_init__(self):
        if self.kind == 'histogram':
            if type(self.value) is not Histogram: raise ValueError('expected Histogram')
        elif self.kind in ('counter', 'gauge'): _natural(self.value, 'metric quantity')
        else: raise ValueError('invalid metric kind')


@dataclass(frozen=True)
class MetricSnapshot:
    revision: int
    epoch: int
    schema: HistogramSchema
    labels: LabelCatalog
    series: tuple[tuple[tuple[str, Labels], MetricValue], ...] = ()
    start: LocalInstant | None = None
    end: LocalInstant | None = None
    complete: bool = True
    temporality: str = 'cumulative'
    gauge_scope: str = 'unknown'
    def __post_init__(self):
        _natural(self.revision, 'snapshot revision'); _natural(self.epoch, 'metric epoch')
        series = tuple((k,v) for k,v in self.series)
        if len(dict(series)) != len(series): raise ValueError('duplicate metric series')
        if self.temporality not in ('cumulative', 'delta'): raise ValueError('invalid temporality')
        object.__setattr__(self, 'series', series)
    def get(self, family, labels=Labels()): return dict(self.series).get((family, labels))
    @classmethod
    def window(cls, start, end):
        if (start.epoch, start.schema, start.labels, start.start, start.gauge_scope) != (end.epoch, end.schema, end.labels, end.start, end.gauge_scope):
            raise ModelError('incompatible metric snapshots')
        if start.temporality != 'cumulative' or end.temporality != 'cumulative': raise ModelError('window requires cumulative endpoints')
        if start.revision > end.revision: raise ModelError('reversed window')
        if start.end is not None and end.end is not None: end.end.elapsed_since(start.end)
        prior, result = dict(start.series), []
        for key, current in end.series:
            old = prior.pop(key, None)
            if old is not None:
                if old.kind != current.kind: raise ModelError('incompatible metric kinds')
                if current.kind == 'counter':
                    if current.value < old.value: raise ModelError('counter reset')
                    current = MetricValue('counter', current.value-old.value)
                elif current.kind == 'histogram':
                    a,b = old.value, current.value
                    if len(a.buckets) != len(b.buckets) or any(y<x for x,y in zip(a.buckets,b.buckets)) or b.sum_ns<a.sum_ns: raise ModelError('counter reset')
                    current = MetricValue('histogram', Histogram(tuple(y-x for x,y in zip(a.buckets,b.buckets)), b.count-a.count, b.sum_ns-a.sum_ns))
            result.append((key,current))
        if prior: raise ModelError('counter reset: series disappeared')
        return replace(end, start=start.end, series=tuple(result), complete=start.complete and end.complete, temporality='delta')
