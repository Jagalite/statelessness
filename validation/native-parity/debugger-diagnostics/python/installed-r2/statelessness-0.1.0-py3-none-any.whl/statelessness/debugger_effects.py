"""Optional host effect lifecycle observations, with explicit clock provenance.

Hooks record host facts; cancellation does not terminate physical work. Tokens
are local capabilities. Retention bounds cover diagnostic records, not RSS or
application allocations. Call publication reservation under the host queue lock.
"""
from collections import deque
from dataclasses import dataclass, field, replace
from copy import deepcopy
from threading import RLock
from .core import _natural, U64_MAX

class LifecycleError(ValueError): pass
class MeasurementError(ValueError): pass

@dataclass(frozen=True)
class LocalInstant:
    domain: int
    nanos: int
    def __post_init__(self):
        _natural(self.domain,'clock domain'); _natural(self.nanos,'nanoseconds')
    def elapsed_since(self,start):
        if type(start) is not LocalInstant: raise MeasurementError('MissingEndpoint')
        if self.domain!=start.domain: raise MeasurementError('DifferentClockDomain')
        if self.nanos<start.nanos: raise MeasurementError('Reversed')
        return self.nanos-start.nanos

@dataclass(frozen=True)
class EffectId:
    run: int
    epoch: int
    serial: int

@dataclass(frozen=True)
class AttemptId:
    effect: EffectId
    serial: int

@dataclass(frozen=True)
class DeliveryId:
    effect: EffectId
    serial: int

@dataclass(frozen=True)
class RequestOrigin:
    run: int
    epoch: int
    machine: int
    transition_sequence: int
    output_index: int
    def __post_init__(self):
        for name in ('run','epoch','machine','transition_sequence','output_index'): _natural(getattr(self,name),name)
        if self.output_index>0xffffffff: raise ValueError('output_index exceeds u32')

@dataclass(frozen=True)
class EffectOptions:
    run: int = 1
    epoch: int = 1
    origin: str = 'Live'
    counters: bool = True
    timings: bool = True
    details: bool = True
    max_details: int = 4096
    max_detail_bytes: int = 8*1024*1024
    max_events_per_effect: int = 128
    max_attempts_per_effect: int = 1024
    max_deliveries_per_effect: int = 1024
    max_pause_intervals: int = 64
    labels: object = None
    histogram: object = None
    metric_limits: object = None
    gauge_scope: str = 'ObservedSinceAttach'
    def __post_init__(self):
        for name in ('run','epoch','max_events_per_effect','max_attempts_per_effect','max_deliveries_per_effect','max_pause_intervals'): _natural(getattr(self,name),name,1)
        for name in ('max_details','max_detail_bytes'): _natural(getattr(self,name),name)
        if self.origin not in ('Live','Synthetic'): raise ValueError('invalid measurement origin')

@dataclass(frozen=True)
class LifecycleEvent:
    sequence: int
    at: LocalInstant | None
    kind: str
    detail: object
    debugger_affected: bool

@dataclass(frozen=True)
class TimingObservation:
    family: object
    duration_ns: int | None
    error: str | None
    attempt: AttemptId | None = None
    delivery: DeliveryId | None = None
    outcome: str = 'None'
    debugger_affected: bool = False

@dataclass
class EffectDetails:
    id: EffectId
    origin: RequestOrigin
    labels: object
    requested: LocalInstant | None
    admission: str | None = None
    resolution: str | None = None
    settled: bool = False
    cancellation_requested: bool = False
    cancellation_acknowledged: bool = False
    running_attempts: int = 0
    deliveries_observed: int = 0
    debugger_affected: bool = False
    abandoned: bool = False
    complete: bool = True
    events: list = field(default_factory=list)
    timings: list = field(default_factory=list)
    def pending_age(self,now):
        if self.resolution is not None or self.admission=='Rejected': return None
        if self.requested is None: raise MeasurementError('MissingEndpoint')
        return now.elapsed_since(self.requested)

class _Effect:
    def __init__(self,owner,id,origin,labels,at,generation,paused):
        self.owner=owner; self.id=id; self.origin=origin; self.labels=labels; self.requested=at
        self.admission=None; self.resolution=None; self.resolved_at=None; self.settled=False
        self.cancel_requested=False; self.cancel_ack=False; self.attempts=0; self.deliveries=0
        self.running=0; self.first_ready=False; self.first_delivery=False; self.observed=0
        self.last_finish=None; self.generation=generation; self.affected=paused; self.abandoned=False

class _Attempt:
    def __init__(self,effect,serial):
        self.effect=effect; self.id=AttemptId(effect.id,serial); self.ready=None; self.queued=False
        self.started=False; self.start=None; self.finished=False; self.finish=None
        self.scheduled=None; self.has_schedule=False; self.abandoned=False; self.previous_finish=effect.last_finish

class _Delivery:
    def __init__(self,effect,serial,posted):
        self.effect=effect; self.id=DeliveryId(effect.id,serial); self.posted=posted
        self.confirmed=False; self.failed=False; self.begun=False; self.begin=None; self.observed=False

class EffectObserver:
    def __init__(self,options,clock):
        from .debugger_metrics import MetricsStore,LabelCatalog,HistogramSchema,MetricLimits,SnapshotTime
        if type(options) is not EffectOptions: raise ValueError('expected EffectOptions')
        self.options=options; self._clock=clock; self._owner=object(); self._lock=RLock()
        self._serial=0; self._sequence=0; self._generation=0; self._paused=False; self._pauses=deque()
        self._details=deque(); self._detail_bytes=0
        self._health={key:0 for key in ('clock_failures','detail_evictions','detail_rejections','detail_event_drops','duplicate_observations','duplicate_deliveries','invalid_lifecycle','abandoned','callback_faults','pause_interval_evictions')}
        at=self._now()
        start=None if at is None else SnapshotTime(at.domain,at.nanos)
        self._metrics=MetricsStore(options.epoch,start,options.labels or LabelCatalog(),options.histogram or HistogramSchema(),options.metric_limits or MetricLimits(),options.gauge_scope)
    def _now(self):
        if not self.options.timings: return None
        try:
            at=self._clock.now() if hasattr(self._clock,'now') else self._clock()
            if type(at) is not LocalInstant: raise MeasurementError('ClockUnavailable')
            return at
        except Exception:
            self._health['clock_failures']+=1; return None
    def _same(self,token):
        e=token if type(token) is _Effect else getattr(token,'effect',None)
        if type(e) is not _Effect or e.owner is not self._owner: raise LifecycleError('ForeignToken')
        return e
    def _fail(self,duplicate=False):
        self._health['duplicate_observations' if duplicate else 'invalid_lifecycle']+=1
        raise LifecycleError('DuplicateObservation' if duplicate else 'WrongPhase')
    def _f(self,name):
        from .debugger_metrics import MetricFamily
        return getattr(MetricFamily,name)
    def _count(self,name,e,outcome='None'):
        if self.options.counters: self._metrics.increment(self._f(name),replace(e.labels,outcome=outcome),1)
    def _gauge(self,name,e,delta):
        if self.options.counters: self._metrics.gauge_delta(self._f(name),e.labels,delta)
    def _detail(self,e): return next((d for d in self._details if d.id==e.id),None)
    def _affected(self,e):
        e.affected |= self._paused or e.generation!=self._generation
    def _event(self,e,kind,detail=None,at=None):
        self._affected(e)
        if self._sequence==U64_MAX: raise LifecycleError('Exhausted')
        self._sequence+=1
        d=self._detail(e)
        if d is None: return
        d.admission=e.admission; d.resolution=e.resolution; d.settled=e.settled
        d.cancellation_requested=e.cancel_requested; d.cancellation_acknowledged=e.cancel_ack
        d.running_attempts=e.running; d.deliveries_observed=e.observed; d.debugger_affected=e.affected; d.abandoned=e.abandoned
        if len(d.events)>=self.options.max_events_per_effect or self._detail_bytes+128>self.options.max_detail_bytes:
            d.complete=False; self._health['detail_event_drops']+=1; return
        d.events.append(LifecycleEvent(self._sequence,at,kind,detail,e.affected)); self._detail_bytes+=128
    def _measure(self,e,name,start,end,attempt=None,delivery=None,outcome='None'):
        if not self.options.timings: return
        self._affected(e); error=None; duration=None
        try:
            if start is None or end is None: raise MeasurementError('MissingEndpoint')
            duration=end.elapsed_since(start)
        except MeasurementError as err: error=str(err)
        family=self._f(name)
        labels=replace(e.labels,outcome=outcome,debugger_affected=e.affected)
        if duration is not None: self._metrics.observe(family,labels,duration)
        d=self._detail(e)
        if d is not None:
            if len(d.timings)>=self.options.max_events_per_effect or self._detail_bytes+128>self.options.max_detail_bytes:
                d.complete=False; self._health['detail_event_drops']+=1
            else:
                d.timings.append(TimingObservation(family,duration,error,attempt,delivery,outcome,e.affected)); self._detail_bytes+=128
                if error: d.complete=False
    def requested(self,origin,labels=None):
        from .debugger_metrics import Labels
        if type(origin) is not RequestOrigin or origin.run!=self.options.run or origin.epoch!=self.options.epoch: raise LifecycleError('WrongEpoch')
        labels=replace(labels or Labels(),origin=self.options.origin,outcome='None',debugger_affected=False)
        if not self._metrics.labels_valid(labels): raise LifecycleError('InvalidLabels')
        with self._lock:
            if self._serial==U64_MAX: raise LifecycleError('Exhausted')
            self._serial+=1; at=self._now(); e=_Effect(self._owner,EffectId(origin.run,origin.epoch,self._serial),origin,labels,at,self._generation,self._paused)
            self._count('REQUESTS',e)
            if self.options.details:
                if not self.options.max_details or self.options.max_detail_bytes<512: self._health['detail_rejections']+=1
                else:
                    while self._details and (len(self._details)>=self.options.max_details or self._detail_bytes+512>self.options.max_detail_bytes):
                        old=self._details.popleft(); self._detail_bytes-=512+128*(len(old.events)+len(old.timings)); self._health['detail_evictions']+=1
                    self._details.append(EffectDetails(e.id,origin,labels,at)); self._detail_bytes+=512
            self._event(e,'Requested',at=at); return e
    def admission(self,e,admission):
        self._same(e)
        if admission not in ('Accepted','Rejected'): raise ValueError('invalid admission')
        with self._lock:
            if e.admission is not None: self._fail(True)
            if e.resolution is not None: self._fail()
            e.admission=admission; self._count('ADMISSIONS',e,admission)
            if admission=='Accepted': self._gauge('UNRESOLVED',e,1)
            self._event(e,'Admission',admission,self._now())
    def attempt_created(self,e):
        self._same(e)
        with self._lock:
            if e.admission!='Accepted' or e.resolution is not None: self._fail()
            if e.attempts>=self.options.max_attempts_per_effect: raise LifecycleError('Limit')
            e.attempts+=1; a=_Attempt(e,e.attempts); self._event(e,'AttemptCreated',a.id); return a
    def retry_scheduled(self,a,delay_ns):
        e=self._same(a); _natural(delay_ns,'delay_ns')
        with self._lock:
            if a.started or a.queued or a.has_schedule or a.abandoned or e.resolution is not None: self._fail()
            a.scheduled=self._now(); a.has_schedule=True
            if self.options.timings: self._metrics.observe(self._f('SCHEDULED_BACKOFF'),e.labels,delay_ns)
            self._event(e,'RetryScheduled',(a.id,delay_ns),a.scheduled)
    def ready_queued(self,a):
        e=self._same(a)
        with self._lock:
            if a.queued: self._fail(True)
            if a.started or a.finished or a.abandoned or e.resolution is not None: self._fail()
            at=self._now(); a.queued=True; a.ready=at; self._gauge('READY_DEPTH',e,1)
            if not e.first_ready: self._measure(e,'ADMISSION_DELAY',e.requested,at,a.id); e.first_ready=True
            if a.has_schedule: self._measure(e,'ELIGIBILITY_WAIT',a.scheduled,at,a.id)
            self._event(e,'Ready',a.id,at)
    def ready_removed(self,a):
        e=self._same(a)
        with self._lock:
            if not a.queued or a.started: self._fail()
            a.queued=False; self._gauge('READY_DEPTH',e,-1)
    def attempt_started(self,a):
        e=self._same(a)
        with self._lock:
            if a.started: self._fail(True)
            if a.finished or a.abandoned or e.resolution is not None: self._fail()
            a.start=self._now(); a.started=True; e.running+=1
            self._count('ATTEMPTS',e); self._gauge('RUNNING',e,1)
            if a.queued:
                a.queued=False; self._gauge('READY_DEPTH',e,-1); self._measure(e,'QUEUE_WAIT',a.ready,a.start,a.id)
            if a.id.serial>1: self._measure(e,'INTER_ATTEMPT_GAP',a.previous_finish,a.start,a.id)
            self._event(e,'AttemptStarted',a.id,a.start)
    def attempt_finished(self,a,outcome):
        e=self._same(a); self._outcome(outcome)
        with self._lock:
            if a.finished: self._fail(True)
            if not a.started: self._fail()
            a.finish=self._now(); a.finished=True; e.last_finish=a.finish; e.running-=1
            self._count('ATTEMPT_OUTCOMES',e,self._label(outcome)); self._gauge('RUNNING',e,-1)
            self._measure(e,'ATTEMPT_ELAPSED',a.start,a.finish,a.id,outcome=self._label(outcome)); self._event(e,'AttemptFinished',(a.id,outcome),a.finish)
    @staticmethod
    def _outcome(value):
        if value not in ('Unclassified','Success','Failure','Cancelled'): raise ValueError('invalid runtime outcome')
    @staticmethod
    def _label(value): return 'None' if value=='Unclassified' else value
    def resolved(self,e,outcome,selected_attempt=None):
        self._same(e); self._outcome(outcome)
        with self._lock:
            if selected_attempt is not None and (self._same(selected_attempt) is not e or not selected_attempt.finished): self._fail()
            if e.resolution is not None: self._fail(True)
            if e.admission!='Accepted': self._fail()
            at=self._now(); e.resolution=outcome; e.resolved_at=at; label=self._label(outcome)
            self._count('RESOLUTIONS',e,label); self._gauge('UNRESOLVED',e,-1); self._measure(e,'RESOLUTION',e.requested,at,outcome=label)
            if selected_attempt: self._measure(e,'RESOLUTION_OVERHEAD',selected_attempt.finish,at,selected_attempt.id,outcome=label)
            self._event(e,'Resolved',outcome,at)
    def cancellation_requested(self,e):
        self._same(e)
        with self._lock:
            if e.cancel_requested: self._fail(True)
            e.cancel_requested=True; self._count('CANCELLATION_REQUESTS',e); self._event(e,'CancellationRequested',at=self._now())
    def cancellation_acknowledged(self,e):
        self._same(e)
        with self._lock:
            if e.cancel_ack: self._fail(True)
            if not e.cancel_requested: self._fail()
            e.cancel_ack=True; self._count('CANCELLATION_ACKNOWLEDGEMENTS',e); self._event(e,'CancellationAcknowledged',at=self._now())
    def reserve_publication(self,e):
        self._same(e)
        with self._lock:
            if e.resolution is None: self._fail()
            if e.deliveries>=self.options.max_deliveries_per_effect: raise LifecycleError('Limit')
            e.deliveries+=1; d=_Delivery(e,e.deliveries,self._now()); self._gauge('COMPLETION_DEPTH',e,1)
            self._event(e,'PublicationReserved',d.id,d.posted); return d
    def publication_committed(self,d):
        e=self._same(d)
        with self._lock:
            if d.failed: self._fail()
            if not d.confirmed:
                d.confirmed=True; self._measure(e,'COMPLETION_PREPARATION',e.resolved_at,d.posted,delivery=d.id)
    def publication_failed(self,d):
        e=self._same(d)
        with self._lock:
            if d.failed: self._fail(True)
            if d.begun or d.confirmed: self._fail()
            d.failed=True; self._gauge('COMPLETION_DEPTH',e,-1); self._event(e,'PublicationFailed',d.id,self._now())
    def delivery_begun(self,d):
        e=self._same(d)
        with self._lock:
            if d.begun: self._fail(True)
            if d.failed: self._fail()
            at=self._now(); self.publication_committed(d); d.begun=True; d.begin=at; self._gauge('COMPLETION_DEPTH',e,-1)
            self._measure(e,'COMPLETION_QUEUE_WAIT',d.posted,at,delivery=d.id); self._measure(e,'DELIVERY_LAG',e.resolved_at,at,delivery=d.id)
            if not e.first_delivery: self._measure(e,'END_TO_END',e.requested,at,delivery=d.id); e.first_delivery=True
            self._event(e,'DeliveryBegun',d.id,at)
    def delivery_observed(self,d,disposition):
        e=self._same(d)
        if disposition not in ('Accepted','Rejected','Ignored'): raise ValueError('invalid disposition')
        with self._lock:
            if d.observed: self._fail(True)
            if not d.begun or d.failed: self._fail()
            at=self._now(); d.observed=True; self._count('DELIVERIES',e,disposition)
            if e.observed: self._count('DUPLICATE_DELIVERIES',e); self._health['duplicate_deliveries']+=1
            else: self._measure(e,'END_TO_END_OBSERVED',e.requested,at,delivery=d.id,outcome=disposition)
            e.observed+=1; self._measure(e,'COMPLETION_PROCESSING',d.begin,at,delivery=d.id,outcome=disposition); self._event(e,'DeliveryObserved',(d.id,disposition),at)
    def settled(self,e):
        self._same(e)
        with self._lock:
            if e.settled: self._fail(True)
            at=self._now(); e.settled=True; self._measure(e,'SETTLEMENT',e.requested,at); self._event(e,'Settled',at=at)
    def attempt_abandoned(self,a):
        e=self._same(a)
        with self._lock:
            if a.abandoned or a.finished: return
            a.abandoned=True; e.abandoned=True; self._health['abandoned']+=1; self._count('ABANDONED',e); self._event(e,'Abandoned',a.id)
    def debugger_pause(self,paused):
        if type(paused) is not bool: raise ValueError('expected bool')
        with self._lock:
            if self._paused==paused: return
            at=self._now(); self._paused=paused
            if paused:
                if self._generation==U64_MAX: raise LifecycleError('Exhausted')
                self._generation+=1
                if len(self._pauses)>=self.options.max_pause_intervals: self._pauses.popleft(); self._health['pause_interval_evictions']+=1
                self._pauses.append(dict(generation=self._generation,start=at,end=None))
            elif self._pauses: self._pauses[-1]['end']=at
    def effect_details(self,id):
        with self._lock: return deepcopy(next((d for d in self._details if d.id==id),None))
    def effect_timeline(self,id):
        d=self.effect_details(id)
        if d is None: return None
        return dict(effect=d.id,origin=d.origin,measurement_origin=self.options.origin,complete=d.complete,events=d.events,timings=d.timings)
    def pause_intervals(self):
        with self._lock: return deepcopy(list(self._pauses))
    def telemetry_health(self):
        with self._lock: return dict(self._health,retained_detail_records=len(self._details),retained_detail_bytes=self._detail_bytes,unobserved_native_debugger_interference_possible=True)
    def metric_snapshot(self):
        from .debugger_metrics import SnapshotTime
        at=self._now(); return self._metrics.snapshot(None if at is None else SnapshotTime(at.domain,at.nanos))
    def metric_window(self,from_revision,to_revision): return self._metrics.window(from_revision,to_revision)
    def available_windows(self): return self._metrics.available_windows()
